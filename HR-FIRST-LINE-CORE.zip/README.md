# Selenium Starter

Quickly get started with [Selenium](https://www.selenium.dev/) using this starter! 

- If you want to upgrade Python, you can change the image in the [Dockerfile](./.devcontainer/Dockerfile).